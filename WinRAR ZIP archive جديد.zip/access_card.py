# mahmmoud najjar 3/10/2026 this program about coding
print("-----------------------------------------------------------------------------------------------------------------------------")
print()
print("mahmmoud , cybersecurity , student sentinel , palestine polytichnic universty")
print()
print("-----------------------------------------------------------------------------------------------------------------------------")