# mahmmoud najjar 3/10/2026 this program about coding
print("Hello Python world!")