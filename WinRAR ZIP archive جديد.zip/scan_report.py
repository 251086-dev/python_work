# mahmmoud najjar 3/10/2026 this program about coding
print("----------------------           Scan Report         --------------------------")
print("*******************************************************************************")
print("name  mahmoud ,, age 80 ,, hobby hobby ") # personal detials
print("country palestine ,, city  idna,, university ppu") # more personal detials
print(" computer laptop ,, phone samsung ,, tablet ipad") # things i use and the things i use in my life and techonlogy
print()
print("the report is complete")